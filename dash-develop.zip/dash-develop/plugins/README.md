# Plugins

Each folder in this directory will get built into a Qt plugin of the same name to `bin/plugins`
