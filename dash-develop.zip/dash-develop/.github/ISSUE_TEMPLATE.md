# Issue

*Make sure you are running the latest version before reporting an issue.*

## Hardware

| Device             | Connection Method | Screen                       | Mobile Device     | Android Auto Version |
| ------------------ | ----------------- | ---------------------------- | ----------------- | -------------------- |
| Raspberry Pi 4 4GB | USB Cable         | Official Raspberry 7" Screen | Samsung Galaxy S8 | v.1.EXAMPLE          |

Installation Method: Install.sh or Image

## Description of problem:

Problem

## Expected Result:

Result

## Problem-relevant steps to reproduce:

1. 
1. 
1. 

## Traceback (if applicable):
```bash

```

## Additional info:

Additional Info